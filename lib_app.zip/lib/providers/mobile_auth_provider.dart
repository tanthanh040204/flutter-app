/*
 * @file       mobile_auth_provider.dart
 * @brief      Authentication state: login/register/logout and profile stream.
 */

/* Imports ------------------------------------------------------------ */
import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/mobile_user_profile.dart';
import '../services/mobile_user_repo.dart';

/* Constants ---------------------------------------------------------- */
/* Enums -------------------------------------------------------------- */
/* Typedef / Function types ------------------------------------------ */

/* Public classes ----------------------------------------------------- */
class MobileAuthProvider extends ChangeNotifier {
  MobileAuthProvider(this._repo);

  /* --- private fields ------------------------------------------ */
  final MobileUserRepo _repo;
  MobileUserProfile? _currentUser;
  StreamSubscription<MobileUserProfile?>? _profileSub;
  bool _loading = false;
  bool _showOnboarding = true;
  String? _error;

  /* --- public getters ------------------------------------------ */
  MobileUserProfile? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get loading => _loading;
  bool get showOnboarding => _showOnboarding;
  String? get error => _error;

  /* --- public methods ------------------------------------------ */
  void finishOnboarding() {
    _showOnboarding = false;
    notifyListeners();
  }

  Future<bool> login({
    required String identifier,
    required String password,
    required bool usePhone,
  }) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final MobileUserProfile user = await _repo.signIn(
        identifier: identifier,
        password: password,
        usePhone: usePhone,
      );
      await _bindProfile(user.uid);
      _currentUser = user;
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<bool> register({
    required String fullName,
    required String employeeCode,
    required String identifier,
    required String password,
    required bool usePhone,
    String? phone,
  }) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final MobileUserProfile user = await _repo.register(
        fullName: fullName,
        employeeCode: employeeCode,
        identifier: identifier,
        password: password,
        usePhone: usePhone,
      );
      await _bindProfile(user.uid);
      _currentUser = user;
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final MobileUserProfile? user = _currentUser;
    if (user == null) throw Exception('You are not signed in.');
    await _repo.changePassword(
      uid: user.uid,
      currentPassword: currentPassword,
      newPassword: newPassword,
    );
  }

  Future<void> logout() async {
    await _repo.signOut();
    await _profileSub?.cancel();
    _profileSub = null;
    _currentUser = null;
    notifyListeners();
  }

  void updateLocalBalance(int newBalance) {
    final MobileUserProfile? user = _currentUser;
    if (user == null) return;
    if (newBalance < 0) return;
    if (user.balance == newBalance) return;
    _currentUser = user.copyWith(balance: newBalance);
    notifyListeners();
  }

  void deductLocalBalance(int amount) {
    final MobileUserProfile? user = _currentUser;
    if (user == null) return;
    if (amount <= 0) return;
    final int nextBalance = (user.balance - amount).clamp(0, user.balance);
    if (nextBalance == user.balance) return;
    _currentUser = user.copyWith(balance: nextBalance);
    notifyListeners();
  }

  @override
  void dispose() {
    _profileSub?.cancel();
    super.dispose();
  }

  /* --- private methods ----------------------------------------- */
  Future<void> _bindProfile(String uid) async {
    await _profileSub?.cancel();
    _profileSub = _repo.watchUserProfile(uid).listen((profile) {
      if (profile != null) {
        _currentUser = profile;
        notifyListeners();
      }
    });
  }
}

/* Private classes ---------------------------------------------------- */
/* Public functions --------------------------------------------------- */
/* Private functions -------------------------------------------------- */
/* Entry point -------------------------------------------------------- */
/* End of file -------------------------------------------------------- */
